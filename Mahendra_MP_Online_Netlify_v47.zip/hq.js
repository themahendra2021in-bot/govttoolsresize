/* hq.js — asli DPI metadata (JPG/PNG) + PDF se seedha high-DPI crop (max 1500 DPI) */
(function () {
  'use strict';
  var MMP = window.MMP = window.MMP || {};
  var MAXDPI = 1500, MAXPX = 90e6;
  // khule hue tool mein jo DPI box/select hai, uski value (50..1500), warna 300
  document.addEventListener('click', function (e) { if (e.target && e.target.id === 'plusRun') MMP.forceDpi = null; }, true);
  MMP.dpi = function () {
    if (MMP.forceDpi) return MMP.forceDpi;
    var m = document.getElementById('modal');
    if ((!m || m.classList.contains('hidden')) && MMP.lastDpi && Date.now() - MMP.lastDpi.t < 8000) return MMP.lastDpi.v;
    if (m && !m.classList.contains('hidden')) {
      var els = m.querySelectorAll('[id$="Dpi"],[id$="dpi"]');
      for (var i = 0; i < els.length; i++) { var v = parseFloat(els[i].value); if (v >= 50 && v <= MAXDPI) return Math.round(v); if (v > MAXDPI) return MAXDPI; }
    }
    return 300;
  };
  var T = null; function crcT() { if (T) return T; T = new Uint32Array(256); for (var n = 0; n < 256; n++) { var c = n; for (var k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1; T[n] = c >>> 0; } return T; }
  function crc(u8, s, e) { var t = crcT(), c = 0xffffffff; for (var i = s; i < e; i++) c = t[(c ^ u8[i]) & 255] ^ (c >>> 8); return (c ^ 0xffffffff) >>> 0; }
  function jpg(u8, d) {
    if (u8[0] !== 0xff || u8[1] !== 0xd8) return u8;
    if (u8[2] === 0xff && u8[3] === 0xe0 && u8[6] === 0x4a && u8[7] === 0x46) { var o = new Uint8Array(u8); o[13] = 1; o[14] = d >> 8; o[15] = d & 255; o[16] = d >> 8; o[17] = d & 255; return o; }
    var app = [0xff, 0xe0, 0, 16, 0x4a, 0x46, 0x49, 0x46, 0, 1, 1, 1, d >> 8, d & 255, d >> 8, d & 255, 0, 0], r = new Uint8Array(u8.length + 18);
    r.set(u8.subarray(0, 2), 0); r.set(app, 2); r.set(u8.subarray(2), 20); return r;
  }
  function png(u8, d) {
    if (u8[0] !== 0x89 || u8[1] !== 0x50) return u8;
    var p = 8; while (p + 12 <= u8.length) { var len = ((u8[p] << 24) | (u8[p + 1] << 16) | (u8[p + 2] << 8) | u8[p + 3]) >>> 0, nm = String.fromCharCode(u8[p + 4], u8[p + 5], u8[p + 6], u8[p + 7]); if (nm === 'pHYs') return u8; if (nm === 'IDAT') break; p += 12 + len; }
    var ppm = Math.round(d / 0.0254), c = new Uint8Array(21);
    c.set([0, 0, 0, 9, 0x70, 0x48, 0x59, 0x73], 0);
    c[8] = ppm >>> 24; c[9] = (ppm >>> 16) & 255; c[10] = (ppm >>> 8) & 255; c[11] = ppm & 255; c[12] = c[8]; c[13] = c[9]; c[14] = c[10]; c[15] = c[11]; c[16] = 1;
    var cc = crc(c, 4, 17); c[17] = cc >>> 24; c[18] = (cc >>> 16) & 255; c[19] = (cc >>> 8) & 255; c[20] = cc & 255;
    var r = new Uint8Array(u8.length + 21); r.set(u8.subarray(0, 33), 0); r.set(c, 33); r.set(u8.subarray(33), 54); return r;
  }
  MMP.setDpi = function (u8, type, d) { return type === 'image/png' ? png(u8, d) : jpg(u8, d); };
  var ob = HTMLCanvasElement.prototype.toBlob, od = HTMLCanvasElement.prototype.toDataURL;
  HTMLCanvasElement.prototype.toBlob = function (cb, type, q) {
    var d = MMP.dpi();
    return ob.call(this, function (b) {
      if (!b || (b.type !== 'image/jpeg' && b.type !== 'image/png')) return cb(b);
      b.arrayBuffer().then(function (ab) { cb(new Blob([MMP.setDpi(new Uint8Array(ab), b.type, d)], { type: b.type })); }, function () { cb(b); });
    }, type, q);
  };
  HTMLCanvasElement.prototype.toDataURL = function (type, q) {
    var s = od.call(this, type, q), m = /^data:(image\/(?:jpeg|png));base64,/.exec(s);
    if (!m) return s;
    try {
      var bin = atob(s.slice(m[0].length)), u = new Uint8Array(bin.length); for (var i = 0; i < bin.length; i++) u[i] = bin.charCodeAt(i);
      var o = MMP.setDpi(u, m[1], MMP.dpi()), out = ''; for (var j = 0; j < o.length; j += 8192) out += String.fromCharCode.apply(null, o.subarray(j, j + 8192));
      return m[0] + btoa(out);
    } catch (e) { return s; }
  };
  window.capPx = function (p) { var a = p.w * p.h; if (a <= MAXPX) return p; var k = Math.sqrt(MAXPX / a); return { w: Math.max(1, Math.floor(p.w * k)), h: Math.max(1, Math.floor(p.h * k)) }; };
  // PDF page se seedha crop ko high DPI par dobara render karo (tez, saaf text). src._pdf={page,scale}
  MMP.hqCrop = async function (src, d, base, dpiEl) {
    var meta = src && src._pdf, dpi = dpiEl ? parseFloat(dpiEl.value) : 0;
    if (dpi >= 50) MMP.lastDpi = { v: Math.min(Math.round(dpi), MAXDPI), t: Date.now() };
    if (!base || !meta || !(dpi > 0)) return base;
    dpi = Math.min(dpi, MAXDPI); var S = dpi / 72;
    if (S <= meta.scale * 1.01) return base;
    var w = d.w / meta.scale * S, h = d.h / meta.scale * S;
    if (w * h > MAXPX) { var k = Math.sqrt(MAXPX / (w * h)); S *= k; w *= k; h *= k; MMP.lastNote = 'DPI अपने-आप ' + Math.round(S * 72) + ' तक घटाई (बहुत बड़ा हिस्सा)'; } else MMP.lastNote = '';
    var c = document.createElement('canvas'); c.width = Math.max(1, Math.round(w)); c.height = Math.max(1, Math.round(h));
    var x = c.getContext('2d', { alpha: false }); x.fillStyle = '#fff'; x.fillRect(0, 0, c.width, c.height);
    var vp = meta.page.getViewport({ scale: S, offsetX: -d.x / meta.scale * S, offsetY: -d.y / meta.scale * S });
    await meta.page.render({ canvasContext: x, viewport: vp }).promise;
    return c;
  };
})();
